Настройки доступа к mysql находятся в файле db.php в папке config
Пользователи админки admin@mail.ru и manager@mail.ru, пароль к обоим 123456
