<?php include $_SERVER['DOCUMENT_ROOT'] . VIEW_DIR . 'layout/header.php'; ?>
    <h1><?=$title?></h1>
    <a href="/">На главную</a>
    <div class="row">
        <?=$text?>
    </div>
<?php include $_SERVER['DOCUMENT_ROOT'] . VIEW_DIR . 'layout/footer.php';

    