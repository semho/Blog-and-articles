<?php 

namespace App\View;

interface Renderable 
{
    public function render();
}
