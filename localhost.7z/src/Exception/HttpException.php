<?php

namespace App\Exception;

class HttpException extends ApplicationException
{

}
