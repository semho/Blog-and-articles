<?php

namespace App\Exception;

use Exception;

class ApplicationException extends Exception
{

}
