<?php

$host = 'localhost';
$dbname = 'cms';
$username = 'root';
$password = 'root';

return [
    'host' => $host,
    'dbname' => $dbname,
    'username' => $username,
    'password' => $password
];